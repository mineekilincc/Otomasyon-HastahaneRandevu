﻿public interface IRandevu
{
    int RandevuId { get; set; }
    string Tarih { get; set; }
    string Saat { get; set; }
    string Brans { get; set; }
    string Doktor { get; set; }
    bool Durum { get; set; }
}