﻿public class NormalRandevu : IRandevu
{
    public int RandevuId { get; set; }
    public string Tarih { get; set; }
    public string Saat { get; set; }
    public string Brans { get; set; }
    public string Doktor { get; set; }
    public bool Durum { get; set; }
}