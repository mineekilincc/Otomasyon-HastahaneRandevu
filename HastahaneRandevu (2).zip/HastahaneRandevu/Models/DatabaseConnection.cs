﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastahaneRandevu.Models
{
    internal class DatabaseConnection
    {
        private static string connectionString = "Data Source=DESKTOP-HAOB67P\\MINE;Initial Catalog=HastahaneRandevu;Integrated Security=True";
        private SqlConnection connection;

        public DatabaseConnection()
        {
            connection = new SqlConnection(connectionString);
        }

        // Bağlantı nesnesini döndürür
        public SqlConnection GetConnection()
        {
            return connection;
        }

        // Bağlantıyı açar
        public void OpenConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        // Bağlantıyı kapatır
        public void CloseConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }
}

