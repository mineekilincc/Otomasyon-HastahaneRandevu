﻿using System;

public class RandevuFactory
{
    private static RandevuFactory _instance;
    private static readonly object _lock = new object();

    private RandevuFactory() { }

    public static RandevuFactory Instance
    {
        get
        {
            if (_instance == null)
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new RandevuFactory();
                    }
                }
            }
            return _instance;
        }
    }

    public IRandevu CreateRandevu(string randevuTipi)
    {
        switch (randevuTipi.ToLower())
        {
            case "normal":
                return new NormalRandevu();
            default:
                throw new ArgumentException("Geçersiz randevu tipi");
        }
    }
}