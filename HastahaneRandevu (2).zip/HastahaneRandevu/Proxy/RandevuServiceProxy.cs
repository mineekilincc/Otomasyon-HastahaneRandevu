﻿using System;
using System.Windows.Forms;

public class RandevuServiceProxy : IRandevuService
{
    private AppointmentService _realService;
    private bool _isAuthenticated;

    public RandevuServiceProxy(bool isAuthenticated)
    {
        _isAuthenticated = isAuthenticated;
        _realService = AppointmentService.Instance;
    }

    public void AddAppointment(string tarih, string saat, string brans, string doktor)
    {
        if (_isAuthenticated)
        {
            _realService.AddAppointment(tarih, saat, brans, doktor);
        }
        else
        {
            MessageBox.Show("Bu işlem için yetkiniz bulunmamaktadır.");
        }
    }

    public void UpdateAppointment(int randevuId, string hastaTC, string hastaSikayet)
    {
        if (_isAuthenticated)
        {
            _realService.UpdateAppointment(randevuId, hastaTC, hastaSikayet);
        }
        else
        {
            MessageBox.Show("Bu işlem için yetkiniz bulunmamaktadır.");
        }
    }
}