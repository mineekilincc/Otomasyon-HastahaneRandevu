﻿public interface IRandevuService
{
    void AddAppointment(string tarih, string saat, string brans, string doktor);
    void UpdateAppointment(int randevuId, string hastaTC, string hastaSikayet);
    
}