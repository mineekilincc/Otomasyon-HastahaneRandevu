﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HastahaneRandevu
{
    class SQLBaglantisi
    {
        public SqlConnection baglanti()
        {
            SqlConnection baglan = new SqlConnection("Data Source=DESKTOP-HAOB67P\\MINE;Initial Catalog=HastahaneRandevu;Integrated Security=True");
            baglan.Open();
            return baglan;
        }
    }
}
