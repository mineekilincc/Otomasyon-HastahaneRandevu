﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlClient;


namespace HastahaneRandevu
{
    public partial class FrmDoktorGiris : Form
    {
        public FrmDoktorGiris()
        {
            InitializeComponent();
        }
        SQLBaglantisi bgl = new SQLBaglantisi();
      
        private void btnDoktorGiris_Click_1(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("Select * from TBL_Doktorlar Where DoktorTC=@p1 AND DoktorSifre=@p2", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", mskTC.Text);
            komut.Parameters.AddWithValue("@p2", DoktorSifre.Text);
            SqlDataReader dr = komut.ExecuteReader();
            if (dr.Read())
            {
                FrmDoktorDetay dd = new FrmDoktorDetay();
                dd.tc = mskTC.Text; // doktor girişte girilen tcyi doktor detay sayfasına taşımak için
                dd.Show();
                this.Hide();
                

            }
            else
            {
                MessageBox.Show("Hatalı Şifre yada TC!");
            }
            bgl.baglanti().Close();
        }
    }
}
