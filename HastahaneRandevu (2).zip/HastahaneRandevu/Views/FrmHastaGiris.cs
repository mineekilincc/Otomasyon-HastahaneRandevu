﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HastahaneRandevu
{
    public partial class FrmHastaGiris : Form
    {
        public FrmHastaGiris()
        {
            InitializeComponent();
        }
        SQLBaglantisi bgl = new SQLBaglantisi();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmHastaGiris_Load(object sender, EventArgs e)
        {

        }

        private void HastaKytLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmHastaKayıt hk = new FrmHastaKayıt();
            hk.Show();
            this.Hide();
        }

        private void btnHastaGiris_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("Select * from TBL_Hastalar Where HastaTC=@P1 AND HastaSifre=@p2", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", mskTC.Text);
            komut.Parameters.AddWithValue("@p2", HastaSifre.Text);
            SqlDataReader dr = komut.ExecuteReader();
            if (dr.Read())
            {
                FrmHastaDetay hd = new FrmHastaDetay();
                hd.tc = mskTC.Text; // hasta girişte girilen tcyi hasta detay sayfasına taşımak için
                hd.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Hatalı Şifre yada TC!");
            }
            bgl.baglanti().Close();
        }

        private void HastaSifre_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
