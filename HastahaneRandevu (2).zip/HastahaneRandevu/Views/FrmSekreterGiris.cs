﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HastahaneRandevu
{
    public partial class FrmSekreterGiris : Form
    {
        public FrmSekreterGiris()
        {
            InitializeComponent();
        }

        SQLBaglantisi bgl = new SQLBaglantisi();
        private void FrmSekreterGiris_Load(object sender, EventArgs e)
        {

        }

        private void btnHastaGiris_Click(object sender, EventArgs e)
        {

        }

        private void btnSekreterGiris_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand(" Select * From TBL_Sekreter where SekreterTC=@P1 and SekreterSifre=@p2", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", mskTC.Text);
            komut.Parameters.AddWithValue("@p2", SekreterSifre.Text);
            SqlDataReader dr = komut.ExecuteReader();
           if (dr.Read())
            {
                FrmSekreterDetay sd = new FrmSekreterDetay();
                sd.TCnumara = mskTC.Text;
                sd.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Hatalı TC ya da şifre!");
            }
            bgl.baglanti().Close();
        }
    }
}
