﻿using System.Data.SqlClient;

namespace HastahaneRandevu.Infrastructure
{
    public class SQLBaglantisi
    {
        private static SQLBaglantisi _instance;
        private static readonly object _lock = new object();
        private SqlConnection _connection;

        private SQLBaglantisi()
        {
            _connection = new SqlConnection("Your_Connection_String");
        }

        public static SQLBaglantisi Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new SQLBaglantisi();
                    }
                    return _instance;
                }
            }
        }

        public SqlConnection GetConnection()
        {
            return _connection;
        }
    }
}
