﻿using HastahaneRandevu.Models;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HastahaneRandevu.Controller
{
    public class AppointmentService
    {
        private DatabaseConnection dbConnection;

        public AppointmentService()
        {
            dbConnection = new DatabaseConnection();
        }

        public void AddAppointment(string tarih, string saat, string brans, string doktor)
        {
            try
            {
                dbConnection.OpenConnection();
                string query = "INSERT INTO TBL_Randevular (RandevuTarih, RandevuSaati, RandevuBrans, RandevuDoktor) VALUES (@r1, @r2, @r3, @r4)";
                using (SqlCommand komutkaydet = new SqlCommand(query, dbConnection.GetConnection()))
                {
                    komutkaydet.Parameters.AddWithValue("@r1", tarih);
                    komutkaydet.Parameters.AddWithValue("@r2", saat);
                    komutkaydet.Parameters.AddWithValue("@r3", brans);
                    komutkaydet.Parameters.AddWithValue("@r4", doktor);

                    komutkaydet.ExecuteNonQuery();
                    MessageBox.Show("Randevu Oluşturuldu!");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                dbConnection.CloseConnection();
            }
        }

        public void UpdateAppointment(int randevuId, string hastaTC, string hastaSikayet)
        {
            try
            {
                dbConnection.OpenConnection();
                string query = "UPDATE TBL_Randevular SET RandevuDurum=1, HastaTC=@p1, HastaSikayet=@p2 WHERE RandevuId=@p3";
                using (SqlCommand komut = new SqlCommand(query, dbConnection.GetConnection()))
                {
                    komut.Parameters.AddWithValue("@p1", hastaTC);
                    komut.Parameters.AddWithValue("@p2", hastaSikayet);
                    komut.Parameters.AddWithValue("@p3", randevuId);

                    komut.ExecuteNonQuery();
                    MessageBox.Show("Randevu Alındı!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                dbConnection.CloseConnection();
            }
        }
    }
}
