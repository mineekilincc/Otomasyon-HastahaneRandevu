﻿using HastahaneRandevu.Infrastructure;
using System.Data.SqlClient;
using HastahaneRandevu.Controllers;


namespace HastahaneRandevu.Controllers
{
    public class RandevuController : Controllers
    {
        public IActionResult Index()
        {
            // Singleton sınıfından veritabanı bağlantısını alın
            SqlConnection connection = SQLBaglantisi.Instance.GetConnection();


            // Veritabanı işlemleri burada yapılır
            // ...

            return View();
        }
    }
}
