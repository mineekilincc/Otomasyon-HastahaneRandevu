﻿public class AppointmentService : IRandevuService
{
    private static AppointmentService _instance;
    private static readonly object _lock = new object();

    private AppointmentService() { }

    public static AppointmentService Instance
    {
        get
        {
            if (_instance == null)
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new AppointmentService();
                    }
                }
            }
            return _instance;
        }
    }

    public void AddAppointment(string tarih, string saat, string brans, string doktor)
    {
        // Randevu ekleme işlemleri
    }

    public void UpdateAppointment(int randevuId, string hastaTC, string hastaSikayet)
    {
        // Randevu güncelleme işlemleri
    }
}